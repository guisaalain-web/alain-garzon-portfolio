# Competidores a vigilar

Tres grupos de competidores, cada uno relevante por una razón distinta.

## Grupo A: Competidores directos (mismo target, mismo rango)

Estos compiten por nuestro mismo cliente. Vigilancia semanal.

### Mr Boho
- Web: https://www.mrboho.com
- Rango de precio: 80-130 €
- Posicionamiento: diseño barcelonés, colorido, "alegre".
- Por qué importa: solapa target con nosotros, pero más colorido. Si bajan
  precios o lanzan minimalismo, es señal.

### Polaroid Eyewear (línea D2C España)
- Web: https://polaroideyewear.com/es
- Rango de precio: 70-150 €
- Posicionamiento: marca histórica de fotografía aplicada a gafas.
- Por qué importa: tienen presupuesto de paid muy superior. Sus campañas
  marcan el precio de adquisición de todo el sector.

## Grupo B: Disruptores low-cost (presión hacia abajo)

Estos no son nuestro target, pero nos presionan en pricing percibido.

### Hawkers
- Web: https://www.hawkersco.com
- Rango de precio: 35-80 €
- Posicionamiento: D2C masivo, agresivo en paid social.
- Por qué importa: marca el "precio ancla" en la cabeza del consumidor
  español. Cuando hacen promo agresiva, nuestra conversión cae.

### Northweek
- Web: https://www.northweek.com
- Rango de precio: 30-70 €
- Por qué importa: similar a Hawkers, pero más TikTok-first. Vigilancia
  ligera para entender qué formatos virales funcionan en sol D2C.

## Grupo C: Aspiracionales (techo del mercado)

No competimos directamente, pero son referencia de calidad.

### Ace & Tate
- Web: https://www.aceandtate.com
- Posicionamiento: holandeses, premium accesible, retail + online.
- Por qué importa: marcan el "techo" estilístico de nuestro segmento.

## Reglas para análisis competitivo

1. **Grupo A se analiza siempre.** Pricing, lanzamientos, reseñas.
2. **Grupo B se analiza solo para pricing y formatos virales.** No
   importa qué reseñas tienen.
3. **Grupo C se analiza solo para tendencias y diseño.** No competimos en
   precio.
4. **Una promoción en Hawkers superior a 30% es señal de alerta.** Avisar
   en el informe.
5. **Un lanzamiento en Mr Boho que solape diseño minimalista es señal
   crítica.** Acción inmediata.
