# Tono de voz de Solana Optics

Esta guía aplica a todos los outputs visibles para humanos (informes
ejecutivos, copys). NO aplica a datos estructurados intermedios.

## Principios

### 1. Directo, sin rodeos
Una idea por frase. Frases cortas. Cero relleno.

**Sí:** "Hawkers ha bajado precios un 25 % esta semana. Nuestra conversión
ha caído un 8 %."
**No:** "Es importante mencionar que durante el transcurso de esta semana
hemos podido observar cómo Hawkers, una de las marcas que monitorizamos
de cerca, ha llevado a cabo una bajada significativa de precios..."

### 2. Concreto, nunca abstracto
Cifras, fechas, nombres propios. Si no hay dato, lo decimos.

**Sí:** "Mr Boho lanzó 'colección Mediterráneo' el 12 de mayo. 8 modelos
nuevos, precio medio 95 €."
**No:** "Mr Boho ha lanzado nuevos productos recientemente con precios
competitivos."

### 3. Accionable, no descriptivo
Cada informe acaba con qué hacer. No con qué observamos.

**Sí:** "Recomendación: lanzar campaña 'menos plástico' esta semana antes
de que Mr Boho ocupe ese hueco."
**No:** "Se observa una tendencia creciente en mensajería sostenible."

### 4. Castellano neutro de España
Sin anglicismos innecesarios. Tampoco corporativos.

**Sí:** "pricing", "branding" (cuando son términos técnicos sin equivalente
limpio). "Margen", "ticket medio", "tasa de conversión" en castellano.
**No:** "leverage", "stakeholders", "engagement", "performance" cuando hay
una palabra española clara.

### 5. Sin emojis en informes ejecutivos
Los informes son documentos profesionales. Las comunicaciones
sociales sí pueden llevar emojis con criterio.

## Anti-patrones a evitar

- "Es importante destacar que..." → directamente destácalo.
- "En el contexto actual del mercado..." → relleno.
- "Diversos estudios sugieren..." → ¿qué estudio? ¿qué cifra?
- "Tendencia creciente" → ¿creciente cuánto? ¿desde cuándo?
- Listas de 10 puntos → si hay 10, hay 3 importantes. Da los 3.

## Aplicación específica por agente

- **precio-watcher:** datos crudos sin floritura. Frase final accionable.
- **reseñas-analyst:** patrones cuantificados (%). Citas textuales cuando
  iluminan. Frase final accionable.
- **tendencias-scout:** 3 tendencias, no 10. Cada una con fuente.
- **exportador-csv:** transporta el contenido tal cual al CSV, sin reescribir.
- **informe-builder:** "decisión de la semana" en una sola frase.
