# Mi marca: Solana Optics

## Identidad

**Nombre:** Solana Optics
**Sector:** Gafas de sol D2C
**Mercado principal:** España
**Antigüedad:** 2 años (fundada Q1 2024)
**Modelo:** 100% online, sin retail físico

## Producto

- Gafas de sol de diseño minimalista, fabricadas con acetato bio.
- Catálogo de 18 modelos, 5 colecciones.
- Precio medio: 89 €. Rango: 65-119 €.
- Lentes polarizadas en todos los modelos.
- Garantía de 2 años, devolución gratuita 30 días.

## Cliente

- 25-38 años, urbano, ingresos medios-altos.
- Sensible al diseño y a la sostenibilidad.
- Compra principalmente vía Instagram y Google.
- Investiga 2-3 marcas antes de decidir.
- Sensible al precio en rangos comparables, pero no busca lo más barato.

## Métricas actuales

- AOV (ticket medio): 94 €
- CAC: 28 €
- Tasa de devolución: 11 %
- Recompra a 12 meses: 23 %
- Margen bruto: 62 %

## Posicionamiento

Solana se posiciona como la opción de diseño consciente entre Hawkers
(más barato, más masivo) y marcas premium europeas (Persol, Ace & Tate).
Nuestro valor diferencial: diseño minimalista + acetato bio + servicio
post-venta excepcional.

## Objetivos del próximo trimestre

1. Subir AOV a 105 € sin sacrificar tasa de conversión.
2. Reducir CAC a 22 € con mejores creativos.
3. Lanzar 2 modelos limited edition para fidelizar recompra.

## Lo que NO somos

- No somos una marca low-cost. No competimos por precio.
- No somos lujo. No usamos materiales caros por usarlos.
- No somos una marca de moda fugaz. Diseñamos para 5+ años.

## Cómo usar este archivo

Cualquier agente que analice competencia, tendencias o reseñas debe
contrastar sus hallazgos con este posicionamiento. Una tendencia es
relevante para nosotros si afecta a nuestro target, nuestro rango de
precio o nuestro posicionamiento. Si no, es ruido.
