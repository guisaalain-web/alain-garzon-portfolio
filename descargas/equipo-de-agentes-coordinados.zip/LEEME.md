# Tu kit post-masterclass · Equipo de agentes con Claude Code

> Material para que repliques en tu negocio lo que viste en directo.
> Una hora de formación cabe aquí dentro, lista para usar.

---

## Qué hay en este kit

### 1. El proyecto completo (`inteligencia-competitiva/`)

Tu plantilla lista para clonar y adaptar a tu marca. Es el sistema que viste
construir en directo, con las 5 capas arquitecturales:

```
inteligencia-competitiva/
├── CLAUDE.md                    ← Reglas globales del proyecto
├── context/                     ← Quién es tu marca
│   ├── mi-marca.md              · Adapta esto a tu negocio
│   ├── competidores.md          · Pon tus competidores reales
│   └── tono-de-voz.md           · Cambia el estilo si quieres
├── .claude/
│   ├── skills/
│   │   └── extraer-datos-producto/SKILL.md
│   └── agents/                  ← Los 5 especialistas
│       ├── precio-watcher.md
│       ├── reseñas-analyst.md
│       ├── tendencias-scout.md
│       ├── informe-builder.md
│       └── exportador-csv.md
└── output/                      ← Aquí aterriza el trabajo
    ├── pricing/
    ├── resenas/
    ├── tendencias/
    ├── informes/
    └── csv/
```

**Cómo lo usas:** copia esta carpeta a tu ordenador. Edita los tres
archivos de `context/` para reflejar tu negocio (nombre, sector,
competidores, tono). Y ya está. Arrancas Claude Code dentro de la carpeta
y el equipo entero funciona contigo.

### 2. La guía de instalación (`de-0-a-tu-primer-agente.pdf`)

De cero a tu primer agente funcionando en 15 minutos. Si nunca has tocado
Claude Code, empieza por aquí. Si ya lo tienes instalado, sáltate los
primeros pasos y ve directo al apartado de "tu primer agente".

### 3. Plantillas para los próximos 5 agentes (`siguientes-5-agentes.md`)

Cinco ideas concretas de agentes que puedes construir esta semana,
ordenadas por dificultad. Plus: un equipo completo de auditoría
trimestral de catálogo (4 agentes coordinados). Cada plantilla incluye
el prompt exacto que copias y pegas en Claude Code.

### 4. Los visuales de la masterclass (`visuales/`)

Por si los quieres consultar más tarde o compartir con tu equipo:

- **`cuando-agente.svg`** — Árbol de decisión. ¿Necesitas un agente
  para esto? Tres preguntas que te dicen la respuesta.
- **`anatomia-agente.svg`** — Las tres capas concéntricas de un agente
  (núcleo, capacidad, opcional).
- **`10-invariantes.svg`** — Lo que NO cambia entre herramientas
  (Claude Code, Cursor, Antigravity).
- **`comparativa-agentes-v2.excalidraw`** — Comparativa honesta de las
  tres herramientas, con precios reales.

---

## Por dónde empezar

**Si quieres entender el sistema antes de tocar nada:** abre los
archivos del proyecto en orden — primero CLAUDE.md, luego los tres de
context/, luego un par de agentes para ver su estructura. En 15 minutos
tienes la radiografía mental.

**Si quieres arrancar ya:** abre el PDF, sigue los pasos, en 15 minutos
tienes Claude Code corriendo. Después clonas el proyecto a tu ordenador
y adaptas los archivos de context/ a tu negocio.

**Si quieres aprender el patrón antes de copiar:** lee
`siguientes-5-agentes.md`. Vas a ver que TODOS los equipos comparten la
misma estructura — varios especialistas en paralelo más un consolidador
al final. Una vez entiendes esa forma, los demás casos los montas tú
solo.

---

## El reto de la semana

El valor real de esta formación no está en haber visto la demo. Está
en construir TÚ tu primer agente, en TU negocio, esta semana.

Mi sugerencia: monta UN agente sencillo (no los cinco). Cualquier tarea
repetitiva que hagas tú a mano y que tenga un input claro y un output
claro. Lo creas, lo usas durante 5 días reales, y el viernes le ajustas
las reglas innegociables según los errores que haya cometido.

En una semana tendrás tu primer agente útil. En cinco semanas, cinco
agentes pulidos. Eso es más valor que cincuenta agentes a medio hacer.

---

## Qué necesitas para que esto funcione

- Claude Pro o superior (el plan que vimos en la masterclass).
- Claude Code instalado (cubierto en el PDF).
- Una idea concreta de qué quieres automatizar (no genérica).
- Tres horas mentales esta semana para construir y probar.

Nada más. No necesitas saber programar, ni instalar MCPs externos, ni
montar bases de datos. Las herramientas de los agentes son todas nativas
de Claude Code.

---

## Si te quedas atascado

Tres cosas que ayudan, por orden:

**Una.** Pregúntale al propio Claude Code: "esto que estoy intentando
no funciona, ¿qué estoy haciendo mal?". Es sorprendentemente bueno
diagnosticando sus propios problemas.

**Dos.** Comprueba `/permissions` dentro de Claude Code. Casi todos los
fallos silenciosos vienen de permisos denegados sin querer.

**Tres.** Vuelve al PDF y revisa la sección "El error más caro que
cometerás". El 80% de los problemas que tendrás están descritos ahí.

---

## La idea que importa

Si te llevas una sola cosa de la masterclass, que sea esta:

**La IA va de 0 a 1 para que tú vayas de 1 a donde quieras.**

Los agentes te quitan el trabajo de empezar — recoger, comparar,
formatear, transcribir, resumir. Lo que hagas con el tiempo que te
liberan, eso es tuyo. Ahí está el juego.

Decidir sigue siendo cosa tuya. Y debe seguir siéndolo.

Buena suerte construyendo.
