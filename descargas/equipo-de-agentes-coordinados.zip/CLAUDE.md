# Sistema de Inteligencia Competitiva

Este proyecto es un sistema multiagente para automatizar la inteligencia
competitiva de una marca D2C de e-commerce. Cada semana, el equipo de
agentes produce un informe ejecutivo con pricing de competidores, análisis
de reseñas, tendencias del sector, y la exportación del informe a un CSV listo para hoja de cálculo.

## Cómo se organiza el proyecto

```
inteligencia-competitiva/
├── CLAUDE.md                    ← Este archivo (las reglas)
├── context/                     ← Quién es la marca y su entorno
│   ├── mi-marca.md
│   ├── competidores.md
│   └── tono-de-voz.md
├── .claude/
│   ├── skills/                  ← Habilidades reutilizables
│   │   └── extraer-datos-producto/
│   └── agents/                  ← Los 5 especialistas
│       ├── precio-watcher.md
│       ├── reseñas-analyst.md
│       ├── tendencias-scout.md
│       ├── exportador-csv.md
│       └── informe-builder.md
└── output/                      ← Entregables
    ├── pricing/
    ├── reseñas/
    ├── tendencias/
    ├── csv/
    └── informes/
```

## Reglas de oro para todos los agentes

Estas reglas las debe respetar cualquier agente que trabaje en este proyecto:

### 1. Contexto antes que generalidad
Antes de empezar cualquier tarea, lee los archivos relevantes de `context/`.
Nunca produzcas un análisis genérico cuando puedes producir uno específico
para esta marca.

### 2. Cero alucinación
Si un dato no se puede verificar (precio no extraíble, reseña no accesible,
fuente no comprobable), repórtalo como "no extraíble" — nunca lo inventes.
Es preferible un informe corto pero veraz que uno largo y dudoso.

### 3. Output ordenado
Cada agente guarda su output completo en la subcarpeta correspondiente
de `output/`, con el formato `{tipo}-{fecha-YYYYMMDD}.md`.
El orquestador recibe solo el resumen + ruta del archivo, no el contenido
completo, para no contaminar el contexto principal.

### 4. Acción sobre análisis
Todo informe debe acabar con al menos una acción concreta y priorizada.
Análisis sin acción = trabajo desperdiciado.

### 5. Tono de voz
Sigue las directrices de `context/tono-de-voz.md`. Aplica a todos los
outputs visibles para humanos (informes), no a los datos
estructurados intermedios.

## Modelo recomendado

Usa `sonnet` por defecto. Solo escala a `opus` para el agente
`informe-builder` si el output final requiere más juicio estratégico.

## Sobre las herramientas

- `WebSearch` y `WebFetch` para investigación externa.
- `Read`, `Write`, `Edit` para manipular archivos del proyecto.
- `Bash` solo en `informe-builder` para listar archivos generados.
- Ninguna herramienta externa: el sistema funciona solo con WebFetch,
  WebSearch, Read, Write y Bash (todas nativas de Claude Code).

## Cuándo intervengo yo (el humano)

Los agentes hacen recolección, comparación y consolidación. **Yo**
mantengo la decisión estratégica. Si un agente detecta algo que requiere
juicio (ej: "el competidor X parece haber abandonado el mercado"), lo
señala en su informe como "REQUIERE REVISIÓN HUMANA" pero no decide por
mí.
