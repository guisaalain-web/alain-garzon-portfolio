---
name: extraer-datos-producto
description: Extrae datos estructurados de una página de producto de e-commerce. Devuelve nombre, precio actual, precio tachado (si existe), descuento porcentual, disponibilidad, y promociones activas. Úsala siempre que necesites datos limpios de una URL de producto en cualquier e-commerce.
---

# Skill: extraer-datos-producto

## Cuándo usar esta skill

Cuando un agente recibe una URL de producto (o varias) y necesita datos
estructurados, limpios y comparables. Esta skill normaliza la extracción
para que distintos agentes la usen de la misma forma.

## Qué hace esta skill

Dado una URL, intenta extraer los siguientes campos en este orden:

1. **nombre_producto** — string. El nombre visible del producto.
2. **precio_actual** — número (sin símbolo de moneda).
3. **moneda** — string (ej: "EUR", "USD").
4. **precio_anterior** — número o null si no hay precio tachado.
5. **descuento_pct** — número (0-100) o null si no hay descuento.
6. **disponible** — boolean.
7. **promociones_visibles** — array de strings con las promos vistas
   (ej: ["envío gratis", "2x1", "código BLACK20"]).
8. **url_canonica** — la URL final tras redirecciones.
9. **fecha_extraccion** — timestamp ISO 8601.

## Cómo procesar

1. Hacer `WebFetch` de la URL.
2. Buscar en el HTML/contenido los selectores típicos:
   - Precio: `<span class="price">`, `data-price=`, schema.org/Product.
   - Descuento: precio tachado suele estar en `<del>` o `<s>`.
   - Promociones: textos visibles cerca del precio con palabras clave
     ("envío gratis", "código", "%", "descuento", "promo").
3. Si un campo no se puede extraer con certeza razonable, devolver `null`.
   **Nunca inventar.**
4. Si la página bloquea el scraping (Cloudflare, captcha, 403), devolver
   un objeto con `error: "scraping_bloqueado"` y la URL.

## Formato de salida

Siempre JSON estructurado. Ejemplo:

```json
{
  "nombre_producto": "Hawkers Polarized One Black",
  "precio_actual": 29.95,
  "moneda": "EUR",
  "precio_anterior": 39.95,
  "descuento_pct": 25,
  "disponible": true,
  "promociones_visibles": ["envío gratis", "2ª unidad -50%"],
  "url_canonica": "https://www.hawkersco.com/products/one-black",
  "fecha_extraccion": "2026-05-27T10:34:00Z"
}
```

Si la extracción falla:

```json
{
  "error": "scraping_bloqueado",
  "url": "https://...",
  "detalle": "Respuesta 403 — protección Cloudflare detectada"
}
```

## Reglas de la skill

1. **No inventes precios.** Si el HTML no es claro, `null`.
2. **Distingue precio del producto del precio del envío.** Solo el del
   producto cuenta.
3. **Devuelve siempre el mismo esquema.** Aunque algunos campos sean null.
4. **No analices.** Esta skill solo extrae. La interpretación (caro/barato,
   bueno/malo) la hace el agente que llama a la skill.
