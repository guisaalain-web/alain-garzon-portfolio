# Los 5 siguientes agentes que deberías construir

> Material descargable post-masterclass

Después de la masterclass tienes el equipo de inteligencia competitiva
funcionando. Estos son los **5 agentes que más impacto te van a dar**
si los construyes en las próximas semanas, en orden de prioridad.

**Cómo usar este documento:** cada agente trae un "prompt de creación"
que copias y pegas literalmente en Claude Code. Antes de pegarlo, asegúrate
de tener tu CLAUDE.md y tu /context/ adaptados a TU marca (no a Solana).
Sin eso, los agentes serán genéricos.

---

## Agente 1 · Auditor de fichas de producto

**Por qué éste primero:** porque tienes 50-500 fichas de producto y
seguramente ninguna está optimizada. Este agente las audita y te dice
exactamente qué cambiar.

**Tiempo ahorrado estimado:** 8-15 horas/mes.

### Prompt para crear el agente

```
Crea un agente en .claude/agents/ llamado auditor-fichas-producto.

Su trabajo: dado una URL de una ficha de producto de mi tienda, auditarla
contra mejores prácticas de e-commerce y devolver una lista priorizada
de mejoras.

Debe analizar:
- Título (longitud, keyword principal, claridad)
- Descripción corta (gancho en primera frase, beneficios vs. features)
- Descripción larga (estructura, escaneabilidad, FAQs cubiertas)
- Imágenes (cantidad, variedad de ángulos, contexto de uso)
- Información técnica (completitud)
- Reseñas (cantidad visible, rating, antigüedad)
- CTA (claridad, fricción, opciones de pago visibles)
- SEO básico (meta description, alt en imágenes, schema markup detectable)

Debe leer context/mi-marca.md y context/tono-de-voz.md antes de auditar.

Para cada problema detectado:
- Severidad (alta / media / baja)
- Qué cambiar exactamente (no abstracto)
- Por qué importa (impacto en conversión)

Output a output/auditorias/ficha-{slug-del-producto}-{fecha}.md.

Herramientas: WebFetch, Read, Write.
Modelo: sonnet.

Reglas innegociables:
- No inventes datos del producto. Solo audita lo que ves.
- Prioriza por impacto en conversión, no por "lo más obvio".
- Si el producto no es accesible, repórtalo. No inventes.
```

---

## Agente 2 · Atención al cliente (FAQs y devoluciones)

**Por qué éste:** porque el 70% de tickets de atención al cliente son
preguntas repetidas. Un agente que los redacta te libera 1-2 horas al
día.

**Tiempo ahorrado estimado:** 10-25 horas/mes.

### Prompt para crear el agente

```
Crea un agente en .claude/agents/ llamado redactor-atencion-cliente.

Su trabajo: dado un mensaje de un cliente (email, WhatsApp, formulario),
redactar una respuesta profesional aplicando mi tono de voz y mis
políticas.

Debe leer:
- context/mi-marca.md (para tono y políticas)
- context/tono-de-voz.md
- context/politicas/ (carpeta nueva que crearás con: devoluciones.md,
  envios.md, garantia.md, faqs.md)

Para cada mensaje recibido:
1. Clasifica el tipo (devolución / queja / consulta producto / envío / otro)
2. Identifica si tiene toda la info que necesita o falta algo
3. Redacta respuesta empática, clara, accionable
4. Si requiere acción humana (reembolso, escalado), márcalo claramente
5. Sugiere si esa pregunta debería entrar a las FAQs públicas

Output a output/respuestas/respuesta-{fecha-hora}.md.

Herramientas: Read, Write.
Modelo: sonnet.

Reglas innegociables:
- NUNCA prometer algo que no esté en las políticas.
- NUNCA inventar plazos o condiciones.
- Si el caso es ambiguo o sensible, marcar "REQUIERE REVISIÓN HUMANA"
  y explicar por qué.
- Empezar siempre validando el sentimiento del cliente antes de
  responder funcionalmente.
```

**Nota:** Para usarlo en producción, conéctalo con un MCP de Gmail o
HelpScout. Eso es nivel 2 — primero practica con copy-paste manual.

---

## Agente 3 · Generador de variaciones de anuncios

**Por qué éste:** si haces paid social, cada creativo necesita 5-10
variaciones de copy. Hacerlo a mano consume horas. Un agente lo hace
en minutos respetando tu marca.

**Tiempo ahorrado estimado:** 6-12 horas/mes.

### Prompt para crear el agente

```
Crea un agente en .claude/agents/ llamado redactor-anuncios.

Su trabajo: dado un producto, un objetivo de campaña, y un ángulo
principal, generar 10 variaciones de copy para anuncios de Meta /
TikTok / Google.

Debe leer:
- context/mi-marca.md (posicionamiento, target, no-go's)
- context/tono-de-voz.md
- context/anuncios-historicos.md (carpeta nueva con anuncios que han
  funcionado: hook + cuerpo + CTA + métrica)

Variaciones a generar:
- 3 con ángulo problema → solución
- 3 con ángulo prueba social / testimonial
- 2 con ángulo educativo / curiosidad
- 2 con ángulo urgencia / oferta

Para cada variación, devolver:
- Hook (primeras 3 palabras críticas)
- Cuerpo (máx 90 palabras)
- CTA
- Plataforma sugerida (Meta / TikTok / Google)
- Predicción de qué métrica optimiza (CTR / CPM / conversión)

Output a output/anuncios/anuncios-{producto}-{fecha}.md.

Herramientas: Read, Write.
Modelo: sonnet.

Reglas innegociables:
- Cero claims que no estén respaldados (no inventes "más de 10.000
  clientes" si no es cierto).
- Cero anglicismos forzados.
- Cada variación debe ser claramente distinta — no variaciones cosméticas
  del mismo copy.
- Respetar las políticas de Meta/TikTok (no usar "tú", no afirmaciones
  médicas, etc.).
```

---

## Agente 4 · Asistente de proveedores

**Por qué éste:** porque escribir emails a proveedores en inglés/chino
con la información correcta y tono profesional consume tiempo, y los
errores cuestan caro.

**Tiempo ahorrado estimado:** 4-8 horas/mes.

### Prompt para crear el agente

```
Crea un agente en .claude/agents/ llamado asistente-proveedores.

Su trabajo: ayudarme con todas las comunicaciones con proveedores —
solicitudes de cotización, reclamaciones de calidad, negociaciones de
plazo, seguimiento de pedidos.

Debe leer:
- context/mi-marca.md
- context/proveedores/ (carpeta nueva: lista-proveedores.md con info
  de cada uno, condiciones-actuales.md con MOQ, plazos, precios negociados)

Para cada solicitud:
1. Identifica el tipo (cotización / reclamación / seguimiento / otro)
2. Identifica el idioma adecuado (inglés por defecto, chino mandarín si
   proveedor en China y tiene email en chino)
3. Redacta email profesional con la estructura adecuada para esa cultura
   de negocio (más directo en inglés, más relacional en chino)
4. Incluye todos los datos relevantes (referencias, cantidades, fechas)
5. Sugiere asuntos del email con CTR alto

Output a output/proveedores/email-{proveedor}-{fecha}.md.

Herramientas: Read, Write.
Modelo: sonnet.

Reglas innegociables:
- NUNCA prometer plazos sin verificarlos.
- NUNCA hacer compromisos económicos en nombre del usuario sin
  marcarlos como "BORRADOR — REQUIERE TU APROBACIÓN".
- Si falta información crítica (referencia, cantidad), preguntar antes
  de redactar.
- En reclamaciones, ser firme pero no agresivo. Reclamar nunca insulta.
```

---

## Agente 5 · Analista de reseñas propias

**Por qué éste:** las reseñas DE TUS CLIENTES son la mina de oro más
infrautilizada de tu negocio. Lo que sale en ellas debería estar en
tus copys, tus FAQs y tu hoja de ruta de producto.

**Tiempo ahorrado estimado:** rescata 20-40h/mes de no-investigación que
nunca hicieras.

### Prompt para crear el agente

```
Crea un agente en .claude/agents/ llamado analista-reseñas-propias.

Su trabajo: leer las reseñas que YO recibo (en mi propia tienda, en
Trustpilot, en Google) y extraer patrones accionables.

Debe leer:
- context/mi-marca.md (productos, posicionamiento)
- context/tono-de-voz.md

Para cada análisis:
1. Recoge reseñas (usuario pega URL de mi página en Trustpilot/Google
   o archivo CSV con reseñas exportadas).
2. Clasifica cada reseña en 4 capas: producto / servicio / delight /
   objeción pre-compra.
3. Detecta patrones (mínimo 3 menciones para considerar patrón).
4. Cruza con catálogo: ¿hay un producto concreto con más quejas?
   ¿hay un punto consistente de delight?
5. Para cada patrón, propone una acción:
   - Si es patrón de dolor → cambio en producto / servicio / copy
   - Si es delight → mensaje destacar en copy
   - Si es objeción pre-compra → FAQ pública

Output a output/reseñas-propias/analisis-{fecha}.md.

Herramientas: WebFetch, Read, Write.
Modelo: sonnet.

Reglas innegociables:
- Cita textual cuando uses una reseña representativa.
- No suavizar críticas duras. Si el cliente está enfadado, el informe
  también lo refleja.
- Distingue dolor recurrente (acción urgente) de dolor anecdótico
  (vigilar).
- No hagas diagnóstico psicológico del cliente. Solo cuantifica.
```

---

## Cómo construirlos sin perder el norte

**Regla de oro:** un agente nuevo a la semana. No más. Construir 5 agentes
en un fin de semana te da agentes mediocres. Construirlos uno a la semana
te da agentes que iteras hasta que son joyas.

**Iteración recomendada:**

1. **Lunes:** creas el agente con el prompt.
2. **Martes-jueves:** lo usas con casos reales.
3. **Viernes:** revisas sus outputs y ajustas las reglas innegociables
   basándote en los errores que ha cometido.

Al cabo de 5 semanas tienes 5 agentes pulidos. Eso es más valor que
50 agentes a medio hacer.

---

## 🎁 Bonus track · Equipo de auditoría de catálogo (3 agentes + 1 consolidador)

Después de construir los 5 agentes individuales de arriba, vas a notar que
el patrón "varios especialistas en paralelo + un consolidador al final" es
el mismo que aprendiste en la masterclass. Aquí lo tienes aplicado a otro
proceso de e-commerce: **la auditoría trimestral de tu catálogo**.

**Por qué este equipo:** es un trabajo que típicamente nadie hace porque
consume demasiado tiempo — un consultor externo te cobra 1.500-3.000 € por
hacerlo una vez. Tu equipo de agentes lo hace cada trimestre, automático,
mientras tú duermes.

**Tiempo ahorrado estimado:** 3-5 días enteros, cada 3 meses.

**Estructura del equipo:**

- `agente-fichas-obsoletas` — Detecta productos descuidados.
- `agente-pricing-margen` — Detecta productos con margen erosionado.
- `agente-rating-productos` — Detecta productos con problemas de calidad.
- `consolidador-auditoria` — Integra los 3 anteriores y prioriza acciones.

### Prompt 1 · Detector de fichas obsoletas

```
Crea un agente en .claude/agents/ llamado agente-fichas-obsoletas.

Su trabajo: recorrer mi catálogo (lista de URLs de productos de mi tienda)
y detectar fichas que están "muertas". Lee context/mi-marca.md primero.

Criterios de ficha obsoleta:
- Sin actualización de descripción en 12+ meses (si hay metadato disponible).
- Sin stock declarado o "agotado" desde hace 6+ meses.
- Imágenes que parecen antiguas (resolución baja, estética desfasada).
- Descripciones con menos de 100 palabras o sin estructura.
- Sin reseñas, o todas las reseñas tienen más de 18 meses.

Para cada producto obsoleto, devuelve:
- URL y nombre del producto.
- Razones concretas por las que se considera obsoleto (lista).
- Severidad (alta/media/baja).
- Acción sugerida: retirar / refrescar / migrar a outlet.

Output a output/auditoria/fichas-obsoletas-{YYYYMMDD}.md.

Herramientas: WebFetch, Read, Write.

Reglas innegociables:
- Nunca catalogues un producto como obsoleto sin al menos 2 criterios.
- No actúes sobre el catálogo. Solo informa. Las decisiones son humanas.
- Si una URL falla, repórtala. No la cuentes como obsoleta por error.
```

### Prompt 2 · Detector de pricing con margen erosionado

```
Crea un agente en .claude/agents/ llamado agente-pricing-margen.

Su trabajo: revisar mi catálogo y detectar productos cuyo margen se ha
deteriorado. Necesita que el usuario le proporcione un CSV con columnas:
SKU, nombre, precio_venta, coste_actual, fecha_ultimo_cambio_precio.

Lee context/mi-marca.md para saber qué margen mínimo objetivo tiene la
marca y qué AOV se busca.

Para cada producto, calcula:
- Margen bruto actual (precio - coste) / precio.
- Comparación con el margen objetivo de la marca.
- Tiempo desde el último cambio de precio.

Detecta:
- Productos con margen bruto por debajo del objetivo (> 5 puntos por debajo).
- Productos sin cambio de precio en más de 12 meses (precio "olvidado").
- Productos cuyo margen ha caído por encima del 10% (si hay histórico).

Output a output/auditoria/pricing-margen-{YYYYMMDD}.md con tabla priorizada
por urgencia.

Herramientas: Read, Write.

Reglas innegociables:
- Si falta una columna en el CSV, repórtalo y continúa con las disponibles.
- No sugieras precios concretos. Solo identifica qué revisar.
- Distingue claramente entre "subir precio" y "renegociar coste" como
  caminos posibles.
```

### Prompt 3 · Analista de rating de productos

```
Crea un agente en .claude/agents/ llamado agente-rating-productos.

Su trabajo: identificar productos de mi catálogo con problemas de calidad
recurrentes según las reseñas que han recibido.

Input: URLs de las páginas de producto en mi propia tienda, donde están
las reseñas de mis clientes (no las de competidores — eso lo hace
reseñas-analyst).

Para cada producto:
1. Recoge las reseñas más recientes (mínimo últimos 6 meses).
2. Calcula rating medio y distribución de estrellas.
3. Tagea las quejas recurrentes (mínimo 3 menciones = patrón).
4. Clasifica el problema: producto / tallas / envío / expectativas.

Detecta como "producto problemático":
- Rating medio por debajo de 4.0 sostenido.
- Patrón de queja recurrente en más del 30% de reseñas negativas.
- Caída de rating en los últimos 3 meses respecto al histórico.

Output a output/auditoria/rating-productos-{YYYYMMDD}.md.

Herramientas: WebFetch, Read, Write.

Reglas innegociables:
- Cita textual cuando uses una reseña representativa.
- No catalogues un producto como problemático con menos de 10 reseñas en
  la ventana analizada — no hay base estadística.
- Distingue problemas de PRODUCTO (acción: revisar con proveedor) de
  problemas de EXPECTATIVA (acción: mejorar copy de ficha).
```

### Prompt 4 · Consolidador de la auditoría

```
Crea un agente en .claude/agents/ llamado consolidador-auditoria.

Su trabajo: leer los 3 outputs de los agentes anteriores y producir el
informe ejecutivo de auditoría trimestral.

Lee:
- output/auditoria/fichas-obsoletas-{fecha}.md
- output/auditoria/pricing-margen-{fecha}.md
- output/auditoria/rating-productos-{fecha}.md
- context/mi-marca.md

Detecta cruces (la parte más valiosa del informe):
- Productos que aparecen en 2 o 3 informes a la vez = prioridad máxima.
- Patrones por categoría: ¿una colección entera con problemas?
- Patrones temporales: ¿productos lanzados en una época concreta?

Produce el informe con:
- Resumen ejecutivo (3 líneas).
- Las 10 acciones priorizadas del trimestre (qué retirar, qué bajar de
  precio, qué revisar con proveedor, qué refrescar).
- Cifras: cuántos productos en cada categoría, % del catálogo afectado.
- Productos "estrella negativa" (los que aparecen en 2+ informes).

Output a output/auditoria/informe-auditoria-{YYYYMMDD}.md.

Herramientas: Read, Write, Bash.

Reglas innegociables:
- No tomes decisiones tú. Prioriza pero deja las decisiones al humano.
- Si los 3 informes apuntan a una misma categoría/proveedor, señálalo
  como hallazgo crítico.
- El informe debe poder leerse en 5 minutos. Si pasa de 2 páginas, es
  demasiado largo.
```

### Cómo lanzar el equipo

Una vez los 4 agentes están creados, lanzas la auditoría con UN solo prompt:

```
Lanza una auditoría completa de mi catálogo.

Que agente-fichas-obsoletas, agente-pricing-margen y agente-rating-productos
trabajen EN PARALELO usando los datos que te paso (URLs en
data/catalogo-urls.txt y CSV de costes en data/costes-actuales.csv).

Cuando los tres terminen, lanza consolidador-auditoria para integrar
todos los hallazgos en el informe trimestral.

Muéstrame el informe final cuando termines.
```

### Por qué este equipo demuestra que aprendiste el patrón

Mira la estructura: 3 especialistas + 1 consolidador, todos paralelos
excepto el último, cada uno con contexto aislado, cada uno con reglas
innegociables, cada uno con output ordenado. **Es exactamente el mismo
esqueleto que el equipo de inteligencia competitiva de la masterclass.**

Cambian los prompts. Cambian los datos. La arquitectura es idéntica. Si
construyes este, has demostrado que entendiste el patrón — no la receta.

---

## Reto: comparte tu agente en Discord

Cuando construyas el primero, comparte en el canal de la masterclass:

```
Agente que he construido: [nombre]
Problema que resuelve: [una frase]
Tiempo que me ahorra: [horas/semana]
Lo más difícil que me ha pasado: [opcional]
```

Los mejores los reviso uno a uno en el próximo directo de la comunidad.
