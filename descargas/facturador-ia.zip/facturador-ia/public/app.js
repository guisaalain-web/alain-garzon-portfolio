/* ═══════════════════════════════════════
   FACTURADOR — Frontend Logic
   ═══════════════════════════════════════ */

const API = '';  // same origin

// ── State ─────────────────────────────────────
let isProcessing = false;

// ── DOM refs ──────────────────────────────────
const dropZone          = document.getElementById('dropZone');
const fileInput         = document.getElementById('fileInput');
const processingPanel   = document.getElementById('processingPanel');
const processingFilename= document.getElementById('processingFilename');
const processingFilesize= document.getElementById('processingFilesize');
const processingStatus  = document.getElementById('processingStatus');
const processingStatusText = document.getElementById('processingStatusText');
const progressBar       = document.getElementById('progressBar');
const resultPanel       = document.getElementById('resultPanel');
const resultIcon        = document.getElementById('resultIcon');
const resultTitle       = document.getElementById('resultTitle');
const resultSubtitle    = document.getElementById('resultSubtitle');
const dataGrid          = document.getElementById('dataGrid');
const historyContainer  = document.getElementById('historyContainer');
const configAlert       = document.getElementById('configAlert');
const configAlertMsg    = document.getElementById('configAlertMsg');
const statusDot         = document.querySelector('.status-dot');
const statusText        = document.querySelector('.status-text');
const toast             = document.getElementById('toast');
const toastMsg          = document.getElementById('toastMsg');

// ── Init ──────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  checkStatus();
  loadHistory();
  setupDropZone();
});

// ── Status Check ──────────────────────────────
async function checkStatus() {
  try {
    const res = await fetch(`${API}/api/status`);
    const data = await res.json();

    if (data.sheetsConnection) {
      statusDot.className = 'status-dot ok';
      statusText.textContent = 'Conectado';
      configAlert.classList.add('hidden');
    } else if (!data.credentials) {
      statusDot.className = 'status-dot error';
      statusText.textContent = 'Sin credenciales';
      showConfigAlert('Falta el archivo credentials.json en la carpeta del proyecto. Consulta las instrucciones de configuración.');
    } else if (!data.sheetsConnection) {
      statusDot.className = 'status-dot warning';
      statusText.textContent = 'Error Sheets';
      const email = data.serviceAccountEmail || '';
      showConfigAlert(
        `No se pudo acceder al Spreadsheet. Asegúrate de compartirlo con: ${email || 'la service account'} (rol Editor).`
      );
    }
  } catch (e) {
    statusDot.className = 'status-dot error';
    statusText.textContent = 'Sin conexión';
  }
}

function showConfigAlert(msg) {
  configAlertMsg.textContent = msg;
  configAlert.classList.remove('hidden');
}

// ── Drop Zone ─────────────────────────────────
function setupDropZone() {
  // Click
  dropZone.addEventListener('click', () => fileInput.click());
  dropZone.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') fileInput.click(); });

  // File selected via input
  fileInput.addEventListener('change', e => {
    if (e.target.files[0]) handleFile(e.target.files[0]);
  });

  // Drag events
  dropZone.addEventListener('dragover', e => {
    e.preventDefault();
    dropZone.classList.add('drag-over');
  });
  dropZone.addEventListener('dragleave', e => {
    if (!dropZone.contains(e.relatedTarget)) {
      dropZone.classList.remove('drag-over');
    }
  });
  dropZone.addEventListener('drop', e => {
    e.preventDefault();
    dropZone.classList.remove('drag-over');
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  });
}

// ── File Handler ──────────────────────────────
async function handleFile(file) {
  if (isProcessing) return;

  // Validate
  if (file.type !== 'application/pdf' && !file.name.toLowerCase().endsWith('.pdf')) {
    showToast('❌ Solo se aceptan archivos PDF');
    return;
  }
  if (file.size > 20 * 1024 * 1024) {
    showToast('❌ El archivo supera el límite de 20 MB');
    return;
  }

  isProcessing = true;
  showProcessingPanel(file);
  hideResultPanel();

  try {
    const result = await uploadFile(file);
    showResult(result.data);
    loadHistory();
    showToast('✅ Factura guardada en Google Sheets');
  } catch (err) {
    showError(err.message || 'Error desconocido al procesar la factura');
  } finally {
    isProcessing = false;
    fileInput.value = '';
  }
}

// ── Upload ────────────────────────────────────
async function uploadFile(file) {
  const formData = new FormData();
  formData.append('pdf', file);

  // Fake progress steps
  const steps = [
    { progress: 15, text: 'Subiendo PDF...' },
    { progress: 40, text: 'Analizando con Gemini AI...' },
    { progress: 75, text: 'Extrayendo datos de la factura...' },
    { progress: 90, text: 'Guardando en Google Sheets...' },
  ];

  let stepIndex = 0;
  const progressInterval = setInterval(() => {
    if (stepIndex < steps.length) {
      const step = steps[stepIndex++];
      progressBar.style.width = step.progress + '%';
      processingStatusText.textContent = step.text;
    }
  }, 1200);

  try {
    const res = await fetch(`${API}/api/upload`, {
      method: 'POST',
      body: formData,
    });

    clearInterval(progressInterval);
    progressBar.style.width = '100%';

    const data = await res.json();

    if (!res.ok || !data.success) {
      throw new Error(data.error || 'Error del servidor');
    }

    return data;
  } catch (err) {
    clearInterval(progressInterval);
    throw err;
  }
}

// ── UI: Processing Panel ──────────────────────
function showProcessingPanel(file) {
  processingFilename.textContent = file.name;
  processingFilesize.textContent = formatBytes(file.size);
  progressBar.style.width = '0%';
  processingStatusText.textContent = 'Subiendo PDF...';

  processingPanel.classList.remove('hidden');
  dropZone.parentElement.style.opacity = '0.5';
  dropZone.style.pointerEvents = 'none';
}

function hideProcessingPanel() {
  processingPanel.classList.add('hidden');
  dropZone.parentElement.style.opacity = '';
  dropZone.style.pointerEvents = '';
}

// ── UI: Result Panel ──────────────────────────
function showResult(data) {
  hideProcessingPanel();

  resultIcon.className = 'result-icon success';
  resultIcon.innerHTML = `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`;
  resultTitle.textContent = '¡Factura procesada con éxito!';
  resultSubtitle.textContent = 'Todos los datos han sido guardados en tu Google Spreadsheet';

  // Build data grid
  const fields = [
    { label: 'Número de Factura', key: 'numero_factura' },
    { label: 'Fecha Factura',     key: 'fecha_factura' },
    { label: 'Fecha Vencimiento', key: 'fecha_vencimiento' },
    { label: 'Proveedor',         key: 'proveedor' },
    { label: 'NIF/CIF Proveedor', key: 'nif_proveedor' },
    { label: 'Dirección Proveedor', key: 'direccion_proveedor' },
    { label: 'Cliente',           key: 'cliente' },
    { label: 'NIF/CIF Cliente',   key: 'nif_cliente' },
    { label: 'Descripción / Concepto', key: 'descripcion' },
    { label: 'Base Imponible',    key: 'base_imponible',  isAmount: true },
    { label: 'IVA (%)',           key: 'iva_porcentaje' },
    { label: 'Cuota IVA',         key: 'cuota_iva',       isAmount: true },
    { label: 'Total Factura',     key: 'total',           isAmount: true },
    { label: 'Forma de Pago',     key: 'forma_pago' },
  ];

  dataGrid.innerHTML = fields.map(f => {
    const val = data[f.key];
    const isEmpty = !val || val.toString().trim() === '';
    const displayVal = isEmpty ? '—' : (f.isAmount ? formatAmount(val) : val);
    const cls = isEmpty ? 'empty' : (f.isAmount ? 'amount' : '');
    return `
      <div class="data-field">
        <div class="data-field-label">${f.label}</div>
        <div class="data-field-value ${cls}">${displayVal}</div>
      </div>`;
  }).join('');

  resultPanel.classList.remove('hidden');
}

function showError(message) {
  hideProcessingPanel();

  resultIcon.className = 'result-icon error';
  resultIcon.innerHTML = `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>`;
  resultTitle.textContent = 'Error al procesar la factura';
  resultSubtitle.textContent = message;

  dataGrid.innerHTML = '';
  resultPanel.classList.remove('hidden');
  showToast('❌ ' + message);
}

function hideResultPanel() {
  resultPanel.classList.add('hidden');
}

// ── Reset ─────────────────────────────────────
function resetUpload() {
  hideResultPanel();
  hideProcessingPanel();
  progressBar.style.width = '0%';
  isProcessing = false;
}

// ── History ───────────────────────────────────
async function loadHistory() {
  historyContainer.innerHTML = `
    <div class="history-loading">
      <div class="spinner small"></div>
      <span>Cargando historial...</span>
    </div>`;

  try {
    const res = await fetch(`${API}/api/facturas`);
    const data = await res.json();

    if (!data.success || data.facturas.length === 0) {
      historyContainer.innerHTML = `
        <div class="history-empty">
          <span>Aún no hay facturas procesadas. ¡Sube tu primera factura!</span>
        </div>`;
      return;
    }

    historyContainer.innerHTML = `
      <div style="overflow-x:auto;">
        <table class="history-table">
          <thead>
            <tr>
              <th>Nº Factura</th>
              <th>Fecha</th>
              <th>Proveedor</th>
              <th>Cliente</th>
              <th>Total</th>
              <th>Procesado</th>
            </tr>
          </thead>
          <tbody>
            ${data.facturas.map(f => `
              <tr>
                <td>${f.numero_factura || '—'}</td>
                <td>${f.fecha_factura || '—'}</td>
                <td title="${f.proveedor}">${truncate(f.proveedor, 24) || '—'}</td>
                <td title="${f.cliente}">${truncate(f.cliente, 24) || '—'}</td>
                <td class="amount">${f.total ? formatAmount(f.total) : '—'}</td>
                <td>${f.fecha_procesado ? f.fecha_procesado.split(',')[0] : '—'}</td>
              </tr>`).join('')}
          </tbody>
        </table>
      </div>`;
  } catch (e) {
    historyContainer.innerHTML = `
      <div class="history-empty">
        <span>No se pudo cargar el historial. Verifica la conexión.</span>
      </div>`;
  }
}

// ── Toast ─────────────────────────────────────
let toastTimeout;
function showToast(message) {
  clearTimeout(toastTimeout);
  toastMsg.textContent = message;
  toast.classList.remove('hidden');
  toastTimeout = setTimeout(() => toast.classList.add('hidden'), 4000);
}

// ── Helpers ───────────────────────────────────
function formatBytes(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
}

function formatAmount(value) {
  const num = parseFloat(String(value).replace(',', '.'));
  if (isNaN(num)) return value;
  return num.toLocaleString('es-ES', { style: 'currency', currency: 'EUR' });
}

function truncate(str, max) {
  if (!str) return '';
  return str.length > max ? str.slice(0, max) + '…' : str;
}
