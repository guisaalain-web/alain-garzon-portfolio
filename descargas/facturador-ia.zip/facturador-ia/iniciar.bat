@echo off
cd /d "%~dp0"
if not exist node_modules (
  echo Instalando dependencias, solo la primera vez...
  call npm install
)
if not exist .env (
  echo.
  echo Falta el archivo .env: copia .env.example como .env y rellena tus claves. Mira LEEME.txt
  pause
  exit /b
)
start "" http://localhost:3000
call npm start
