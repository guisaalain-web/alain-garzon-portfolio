require('dotenv').config();
const express = require('express');
const multer = require('multer');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const { google } = require('googleapis');
const { GoogleGenerativeAI } = require('@google/generative-ai');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Multer - almacenamiento en memoria
const storage = multer.memoryStorage();
const upload = multer({
  storage,
  limits: { fileSize: 20 * 1024 * 1024 }, // 20MB max
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'application/pdf') {
      cb(null, true);
    } else {
      cb(new Error('Solo se aceptan archivos PDF'), false);
    }
  }
});

// Inicializar Gemini
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

// Inicializar Google Sheets
async function getSheetsClient() {
  const credentialsPath = process.env.CREDENTIALS_PATH || './credentials.json';
  
  if (!fs.existsSync(credentialsPath)) {
    throw new Error('No se encontró credentials.json. Por favor coloca el archivo en la carpeta del proyecto.');
  }

  const credentials = JSON.parse(fs.readFileSync(credentialsPath, 'utf8'));
  
  const auth = new google.auth.JWT({
    email: credentials.client_email,
    key: credentials.private_key,
    scopes: ['https://www.googleapis.com/auth/spreadsheets'],
  });

  return google.sheets({ version: 'v4', auth });
}

// Obtener nombre real de la primera hoja
async function getFirstSheetName(sheets, spreadsheetId) {
  const meta = await sheets.spreadsheets.get({ spreadsheetId });
  return meta.data.sheets[0].properties.title;
}

// Verificar/crear cabeceras en el Sheet
async function ensureHeaders(sheets, spreadsheetId) {
  try {
    const sheetName = await getFirstSheetName(sheets, spreadsheetId);
    const response = await sheets.spreadsheets.values.get({
      spreadsheetId,
      range: `${sheetName}!A1:N1`,
    });

    const firstRow = response.data.values?.[0];
    const headers = [
      'Número Factura', 'Fecha Factura', 'Fecha Vencimiento',
      'Proveedor', 'NIF/CIF Proveedor', 'Dirección Proveedor',
      'Cliente', 'NIF/CIF Cliente',
      'Descripción / Concepto', 'Base Imponible',
      'IVA (%)', 'Cuota IVA', 'Total Factura',
      'Forma de Pago', 'Fecha Procesado'
    ];

    if (!firstRow || firstRow[0] !== 'Número Factura') {
      await sheets.spreadsheets.values.update({
        spreadsheetId,
        range: `${sheetName}!A1`,
        valueInputOption: 'USER_ENTERED',
        requestBody: { values: [headers] },
      });

      // Formatear cabeceras (negrita y fondo azul oscuro)
      await sheets.spreadsheets.batchUpdate({
        spreadsheetId,
        requestBody: {
          requests: [
            {
              repeatCell: {
                range: { sheetId: 0, startRowIndex: 0, endRowIndex: 1, startColumnIndex: 0, endColumnIndex: headers.length },
                cell: {
                  userEnteredFormat: {
                    backgroundColor: { red: 0.106, green: 0.192, blue: 0.349 },
                    textFormat: { bold: true, foregroundColor: { red: 1, green: 1, blue: 1 }, fontSize: 11 },
                    horizontalAlignment: 'CENTER',
                  }
                },
                fields: 'userEnteredFormat(backgroundColor,textFormat,horizontalAlignment)'
              }
            },
            {
              autoResizeDimensions: {
                dimensions: { sheetId: 0, dimension: 'COLUMNS', startIndex: 0, endIndex: headers.length }
              }
            }
          ]
        }
      });
    }
  } catch (err) {
    console.error('Error verificando cabeceras:', err.message);
  }
}

// Extraer datos del PDF con Gemini
async function extractInvoiceData(pdfBuffer, filename) {
  const model = genAI.getGenerativeModel({ model: 'gemini-2.5-flash' });

  const pdfBase64 = pdfBuffer.toString('base64');

  const prompt = `Eres un experto en análisis de facturas. Analiza este PDF de factura y extrae TODOS los datos relevantes.

Devuelve ÚNICAMENTE un JSON válido con exactamente esta estructura (sin markdown, sin explicaciones, solo el JSON):
{
  "numero_factura": "número o código de la factura",
  "fecha_factura": "fecha en formato DD/MM/YYYY",
  "fecha_vencimiento": "fecha de vencimiento en formato DD/MM/YYYY o vacío si no hay",
  "proveedor": "nombre completo del emisor/proveedor",
  "nif_proveedor": "NIF, CIF o número fiscal del proveedor",
  "direccion_proveedor": "dirección completa del proveedor",
  "cliente": "nombre completo del receptor/cliente",
  "nif_cliente": "NIF, CIF o número fiscal del cliente o vacío si no aparece",
  "descripcion": "descripción o concepto principal de la factura",
  "base_imponible": "importe base sin IVA en formato numérico (ej: 1234.56)",
  "iva_porcentaje": "porcentaje de IVA aplicado (ej: 21)",
  "cuota_iva": "importe del IVA en formato numérico (ej: 259.27)",
  "total": "importe total en formato numérico (ej: 1493.83)",
  "forma_pago": "forma de pago (transferencia, tarjeta, efectivo, etc.) o vacío si no aparece"
}

Si algún campo no está disponible en la factura, usa una cadena vacía "".
Si hay múltiples tipos de IVA, usa el principal o el total combinado.
Para los importes, usa punto decimal, no coma.`;

  const result = await model.generateContent([
    prompt,
    {
      inlineData: {
        mimeType: 'application/pdf',
        data: pdfBase64,
      }
    }
  ]);

  const responseText = result.response.text().trim();
  
  // Limpiar posible markdown
  const jsonMatch = responseText.match(/\{[\s\S]*\}/);
  if (!jsonMatch) {
    throw new Error('Gemini no devolvió un JSON válido');
  }

  return JSON.parse(jsonMatch[0]);
}

// Escribir datos en Google Sheets
async function writeToSheet(data, filename) {
  const sheets = await getSheetsClient();
  const spreadsheetId = process.env.SPREADSHEET_ID;

  await ensureHeaders(sheets, spreadsheetId);

  const now = new Date().toLocaleString('es-ES', { timeZone: 'Europe/Madrid' });

  const row = [
    data.numero_factura || '',
    data.fecha_factura || '',
    data.fecha_vencimiento || '',
    data.proveedor || '',
    data.nif_proveedor || '',
    data.direccion_proveedor || '',
    data.cliente || '',
    data.nif_cliente || '',
    data.descripcion || '',
    data.base_imponible || '',
    data.iva_porcentaje || '',
    data.cuota_iva || '',
    data.total || '',
    data.forma_pago || '',
    now,
  ];

  const sheetName = await getFirstSheetName(sheets, spreadsheetId);

  await sheets.spreadsheets.values.append({
    spreadsheetId,
    range: `${sheetName}!A1`,
    valueInputOption: 'USER_ENTERED',
    insertDataOption: 'INSERT_ROWS',
    requestBody: { values: [row] },
  });

  return { success: true, row };
}

// ─── RUTAS ─────────────────────────────────────────────────────────────────

// Status check
app.get('/api/status', async (req, res) => {
  const status = {
    server: 'ok',
    gemini: !!process.env.GEMINI_API_KEY,
    credentials: fs.existsSync(process.env.CREDENTIALS_PATH || './credentials.json'),
    spreadsheetId: process.env.SPREADSHEET_ID || null,
  };

  // Probar conexión a Sheets
  if (status.credentials) {
    try {
      const sheets = await getSheetsClient();
      await sheets.spreadsheets.get({ spreadsheetId: process.env.SPREADSHEET_ID });
      status.sheetsConnection = true;

      // Obtener email de service account
      const creds = JSON.parse(fs.readFileSync(process.env.CREDENTIALS_PATH || './credentials.json', 'utf8'));
      status.serviceAccountEmail = creds.client_email;
    } catch (e) {
      status.sheetsConnection = false;
      status.sheetsError = e.message;
    }
  }

  res.json(status);
});

// Procesar factura
app.post('/api/upload', upload.single('pdf'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No se recibió ningún archivo PDF' });
    }
    if (!process.env.GEMINI_API_KEY || process.env.GEMINI_API_KEY.startsWith('pega_')) {
      return res.status(400).json({ error: 'Falta tu clave de Gemini: ponla en GEMINI_API_KEY dentro del archivo .env (ver LEEME.txt).' });
    }
    if (!process.env.SPREADSHEET_ID || process.env.SPREADSHEET_ID.startsWith('pega_') || !fs.existsSync(process.env.CREDENTIALS_PATH || './credentials.json')) {
      return res.status(400).json({ error: 'Falta conectar Google Sheets: revisa SPREADSHEET_ID en .env y que credentials.json esté en la carpeta (ver LEEME.txt).' });
    }

    console.log(`📄 Procesando: ${req.file.originalname} (${(req.file.size / 1024).toFixed(1)} KB)`);

    // Extraer datos con Gemini
    console.log('🤖 Analizando con Gemini...');
    const invoiceData = await extractInvoiceData(req.file.buffer, req.file.originalname);
    console.log('✅ Datos extraídos:', invoiceData);

    // Escribir en Google Sheets
    console.log('📊 Escribiendo en Google Sheets...');
    const result = await writeToSheet(invoiceData, req.file.originalname);
    console.log('✅ Guardado en Sheets');

    res.json({
      success: true,
      filename: req.file.originalname,
      data: invoiceData,
      message: 'Factura procesada y guardada correctamente'
    });

  } catch (error) {
    console.error('❌ Error:', error.message);
    res.status(500).json({
      error: error.message,
      success: false
    });
  }
});

// Obtener últimas facturas
app.get('/api/facturas', async (req, res) => {
  try {
    const sheets = await getSheetsClient();
    const spreadsheetId = process.env.SPREADSHEET_ID;

    const sheetName = await getFirstSheetName(sheets, spreadsheetId);

    const response = await sheets.spreadsheets.values.get({
      spreadsheetId,
      range: `${sheetName}!A2:O`,
    });

    const rows = response.data.values || [];
    const facturas = rows.map((row, i) => ({
      id: i + 1,
      numero_factura: row[0] || '',
      fecha_factura: row[1] || '',
      fecha_vencimiento: row[2] || '',
      proveedor: row[3] || '',
      nif_proveedor: row[4] || '',
      direccion_proveedor: row[5] || '',
      cliente: row[6] || '',
      nif_cliente: row[7] || '',
      descripcion: row[8] || '',
      base_imponible: row[9] || '',
      iva_porcentaje: row[10] || '',
      cuota_iva: row[11] || '',
      total: row[12] || '',
      forma_pago: row[13] || '',
      fecha_procesado: row[14] || '',
    })).reverse(); // Más recientes primero

    res.json({ success: true, facturas });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.listen(PORT, () => {
  console.log(`\n🚀 Facturador iniciado en http://localhost:${PORT}`);
  console.log(`📊 Spreadsheet: https://docs.google.com/spreadsheets/d/${process.env.SPREADSHEET_ID}`);
  console.log(`🔑 Gemini API: ${process.env.GEMINI_API_KEY ? '✅ Configurada' : '❌ Falta GEMINI_API_KEY'}`);
  console.log(`📁 Credentials: ${fs.existsSync(process.env.CREDENTIALS_PATH || './credentials.json') ? '✅ Encontrado' : '❌ Falta credentials.json'}\n`);
});
